#!/bin/bash
. ~/installer/config/set_env

read -p "Enter CMD to be executed on remote hosts: " CMD
for i in `cat ${SOURCE_DIR}/hdfs.group` ;
do
echo "-------------------------"
echo "Executing command on Host : $i"
echo "-------------------------"

ssh -i ${SSHKEY} -o StrictHostKeyChecking=no -q -t ec2-user@${i} "/usr/bin/sudo $CMD"
done
