#!/bin/bash
. ~/installer/config/set_env

PASS=$1

sudo cp ~/installer/install_files/.my.cnf /root/

sudo replace "Password_text" $PASS -- /root/.my.cnf
#sudo cat /root/.my.cnf
