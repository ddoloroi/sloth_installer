read -p "Enter Fully qualified hostname where MySQL will be installed: " CMD
read -p "Enter MySQL root password: " MYSQLPASS
i=${CMD}
rm -fr $PWD/mysql-connector-java-*.gz*
HOSTNAME=`hostname`
		if [ "$CMD" == "$HOSTNAME" ] ; then
sudo service mysqld stop
sudo rm /var/lib/mysql 
sudo rm -fr /root/.my.cnf
sudo yum clean all
sudo yum erase -y mysql mysql-server
sudo yum install -y mysql mysql-server
sudo service mysqld start
sudo wget http://dev.mysql.com/get/Downloads/Connector-J/mysql-connector-java-5.1.40.tar.gz
sudo rm -fr /tmp/mysql_installs
sudo mkdir /tmp/mysql_installs
sudo tar -zxvf $PWD/mysql-connector-java-5.1.40.tar.gz -C /tmp/mysql_installs &> /dev/null
sudo mkdir -p /usr/share/java/
sudo cp /tmp/mysql_installs/mysql-connector-java-5.1.40/mysql-connector-java-5.1.40-bin.jar /usr/share/java/mysql-connector-java.jar
sudo cp $PWD/install_files/my.cnf.template /etc/my.cnf
sudo service mysqld start
sudo chkconfig mysqld on
sudo mysql_secure_installation <<EOF

y
$MYSQLPASS
$MYSQLPASS
y
y
y
y
EOF
sudo $PWD/Set_MySQL_Password.sh $MYSQLPASS
else
echo "-------------------------"
echo "Executing command on Host : $i"
echo "-------------------------"
#ssh -i CDH.pem -q -t ec2-user@${i} "/usr/bin/sudo wget http://download.fedoraproject.org/pub/epel/6/x86_64/epel-release-6-8.noarch.rpm ; /usr/bin/sudo rpm -ivh epel-release-6-8.noarch.rpm"
ssh -i CDH.pem -q -t ec2-user@${i} "/usr/bin/sudo yum clean all"
ssh -i CDH.pem -q -t ec2-user@${i} "/usr/bin/sudo yum install -y mysql mysql-server"
ssh -i CDH.pem -q -t ec2-user@${i} "/usr/bin/sudo service mysqld start"
ssh -i CDH.pem -q -t ec2-user@${i} "/usr/bin/sudo service mysqld start"
fi
