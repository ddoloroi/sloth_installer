#!/bin/bash
SOURCE_DIR=$PWD
for i in `cat hdfs.group` ;
do
echo "Reboot will be required for new setting to take effect"
read -p "Proceed with Reboot? - Values (Y or y):  " CMD
if [ "$CMD" == "y" ]; then
  echo "x has the value 'valid'"
echo -- $CMD
echo ssh -i CDH.pem -q -t ec2-user@${i} "/usr/bin/sudo reboot"
else
echo "Reboot canceled per user request!"
fi


done
